import React from "react";
import ReactDOM from "react-dom/client";

import App from "./App";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <>
    <>
      <div className="container">
        <div className="header"></div>
        <div className="row filtter">
          <div className="col-10"></div>
          <div className="col-2">
            <button>Clear</button>
          </div>
        </div>
        <App />
      </div>
    </>
  </>
);
