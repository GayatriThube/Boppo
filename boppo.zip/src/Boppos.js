import React from "react";
import { useState, useEffect } from "react";
import "./style.css";

export default function Boppos() {
  const [jobs, setJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [filters, setFilters] = useState({
    location: "",
    role: "",
  });

  useEffect(() => {
    fetch("https://boppotech.github.io/react-task-json.github.io/joblist.json")
      .then((response) => response.json())
      .then((data) => {
        setJobs(data);
        setFilteredJobs(data);
      })
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  const handleFilterChange = (event) => {};
  return (
    <div className="App">
      <h1>Job Listings</h1>
      <div className="filters">
        <input
          type="text"
          name="location"
          placeholder="Filter By Location"
          value={filters.location}
          onChange={handleFilterChange}
        />
      </div>
      <input
        type="text"
        name="role"
        placeholder="Filter By role"
        value={filters.role}
        onChange={handleFilterChange}
      />
    </div>
  );
}
