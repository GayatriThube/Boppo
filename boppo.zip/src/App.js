import React, { useEffect, useState } from "react";

import "./style.css";

export default function App() {
  const [data, setdata] = useState([]);
  const i = 0;
  const getapi = async () => {
    const response = await fetch(
      "https://boppotech-admin.github.io/react-task-json.github.io/joblist.json"
    );
    const apidata = await response.json();
    setdata(apidata);
  };
  useEffect(() => {
    getapi();
  });
  return (
    <>
      {data.map((pdata) => {
        return (
          <div>
            <div className="container details">
              <div className="row">
                <div className="col-2">
                  <img
                    className="compony-logo"
                    src={pdata.companyImage}
                    alt={pdata.companyName}
                  />
                </div>
                <div className="col-6">
                  <h5 className="company-name">{pdata.company.companyName}</h5>
                  <h4>{pdata.jobTitle}</h4>
                  <p>{pdata.formattedAddress}</p>
                </div>
                <div className="col-4">
                  <button value={pdata.skills[i]}></button>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </>
  );
}
